Credential for admin panel :
Username: admin
Password: admin

Credential for user :
Username: theson@gmail.com
Password: 123
Or Register a new user.
