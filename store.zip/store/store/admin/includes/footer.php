<!--footer-->
    <div class="footer">
       <p>&copy; 2024 Admin | Quản lý cửa hàng sửa chữa máy tính.</p>
    </div>
        <!--//footer-->