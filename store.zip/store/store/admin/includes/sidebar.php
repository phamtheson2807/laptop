  <div class=" sidebar" role="navigation">
            <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
          <ul class="nav" id="side-menu">
            <li>
              <a href="dashboard.php"><i class="fa fa-home nav_icon"></i>Thống kê</a>
            </li>
            <li>
              <a href="add-services.php"><i class="fa fa-cogs nav_icon"></i>Dịch vụ<span class="fa arrow"></span> </a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="add-services.php">Thêm dịch vụ</a>
                </li>
                <li>
                  <a href="manage-services.php">Quản lý dịch vụ</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
            </li>
            <li class="">
              <a href="about-us.php"><i class="fa fa-book nav_icon"></i>Trang <span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="about-us.php">Về chúng tôi</a>
                </li>
                <li>
                  <a href="contact-us.php">Liên hệ</a>
                </li>
              </ul>
              <!-- /nav-second-level -->
            </li>
          
            <li>
              <a href="all-appointment.php"><i class="fa fa-check-square-o nav_icon"></i>Lịch hẹn<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li>
                  <a href="all-appointment.php">Tất cả các lịch hẹn</a>
                </li>
                <li>
                  <a href="new-appointment.php">Lịch hẹn mới</a>
                </li>
                <li>
                  <a href="accepted-appointment.php">Lịch hẹn đã duyệt</a>
                </li>
                <li>
                  <a href="rejected-appointment.php">Lịch hẹn đã từ chối</a>
                </li>
              </ul>
              <!-- //nav-second-level -->
            </li>
           
        
           <li>
              <a href="readenq.php"><i class="fa fa-check-square-o nav_icon"></i>Lời nhắn yêu cầu<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                <li><a href="readenq.php">Đọc lời nhắn yêu cầu</a></li>
        <li><a href="unreadenq.php">Không đọc lời nhắn yêu cầu</a></li>
               
              </ul>
              <!-- //nav-second-level -->
            </li>
             <li>
              <a href="customer-list.php" class="chart-nav"><i class="fa fa-users nav_icon"></i>Danh sách khách hàng</a>
            </li>
              <li>
              <a href="#"><i class="fa fa-check-square-o nav_icon"></i>Báo cáo<span class="fa arrow"></span></a>
              <ul class="nav nav-second-level collapse">
                 <li><a href="bwdates-reports-ds.php"> Báo cáo theo ngày</a></li>
                   
                    <li><a href="sales-reports.php">Báo cáo bán hàng</a></li>
              </ul>
              <!-- //nav-second-level -->
            </li>

    <li>
              <a href="invoices.php" class="chart-nav"><i class="fa fa-file-text-o nav_icon"></i>Hóa đơn</a>
            </li>
            <li>
              <a href="search-appointment.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Tìm kiếm lịch hẹn</a>
            </li>
            <li>
              <a href="search-invoices.php" class="chart-nav"><i class="fa fa-search nav_icon"></i>Tìm kiếm hóa đơn</a>
            </li>
          

          </ul>
          <div class="clearfix"> </div>
          <!-- //sidebar-collapse -->
        </nav>
      </div>
    </div>